package com.example.playground.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class PlaySiteFactory{

    @Bean
    @Qualifier("doubleSwings") // bean name is same as class name with the first letter being lowercase
    private final PlaySite doubleSwings() {
        return new PlaySite(PlaySiteType.DOUBLE_SWINGS, 2);
    };

    @Bean
    @Qualifier("carousel")
    private final PlaySite carousel() {
        return new PlaySite(PlaySiteType.CAROUSEL, 9);
    }

    @Bean
    @Qualifier("slide")
    private final PlaySite slide() {
        return new PlaySite(PlaySiteType.SLIDE, 5);
    }

    @Bean
    @Qualifier("ballPit")
    private final PlaySite ballPit() {
        return new PlaySite(PlaySiteType.BALL_PIT, 15);
    }

    public PlaySite getPlaySite(final String playSiteType){
        if(playSiteType.equals("DOUBLE_SWINGS")){
            return this.doubleSwings();
        } else if (playSiteType.equals("CAROUSEL")){
            return this.carousel();
        } else if (playSiteType.equals("SLIDE")){
            return this.slide();
        } else if (playSiteType.equals("BALL_PIT")){
            return this.ballPit();
        } else {
            throw new IllegalArgumentException("No bean available for the type " + playSiteType);
        }
    }
}
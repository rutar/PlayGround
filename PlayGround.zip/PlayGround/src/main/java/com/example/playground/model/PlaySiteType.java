package com.example.playground.model;

public enum PlaySiteType {DOUBLE_SWINGS, CAROUSEL, SLIDE, BALL_PIT}

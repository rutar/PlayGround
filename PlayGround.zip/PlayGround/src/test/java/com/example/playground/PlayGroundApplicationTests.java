package com.example.playground;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlayGroundApplicationTests {

    @Test
    void contextLoads() {
    }

}
